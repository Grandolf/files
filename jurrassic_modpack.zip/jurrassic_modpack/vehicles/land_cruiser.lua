
local name = "land_cruiser"

local definition = {
	description = "Land Cruiser",
	collisionbox = {-1.6, -0.05, -1.3, 1.0, 1, 0.5},
	onplace_position_adj = -0.45,
	is_boat = false,
	player_rotation = {x=0,y=90,z=0},
	driver_attach_at = {x=0,y=12,z=0},
	number_of_passengers = 1,
	passenger_attach_at = {x=0,y=12,z=-8},
	passenger_eye_offset = {x=8, y=0, z=0},
	inventory_image = "cruiserinv.png",
	wield_image = "cruiserinv.png",
	wield_scale = {x=1, y=1, z=1},
	visual = "mesh",
	mesh = "car.x",
	textures = {"roof.png","jurassic_cruiser.png"},
	visual_size = {x=1, y=1},
	stepheight = 1.1,
	max_speed_forward = 20,
	max_speed_reverse = 10,
	accel = 2,
	braking = 4,
	turn_speed = 2,
	drop_on_destroy = "vehicles:land_cruiser",
}

vehicles:register_vehicle("vehicles:"..name, definition)
