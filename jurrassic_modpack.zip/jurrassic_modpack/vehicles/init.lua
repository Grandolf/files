
-- settings

-- end settings

-- get mod path
local mpath = minetest.get_modpath("vehicles")

-- load framework
dofile(mpath.."/framework.lua")
dofile(mpath.."/crafting.lua")


-- ***********************
-- load vehicles down here
-- ***********************

-- Cars
dofile(mpath.."/land_cruiser.lua")
