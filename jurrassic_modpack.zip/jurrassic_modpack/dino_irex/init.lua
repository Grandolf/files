-------------------------------------------------------------------------------
-- Mob Framework Mod by Sapier
-------------------------------------------------------------------------------

-- Boilerplate to support localized strings if intllib mod is installed.
local S
if (minetest.get_modpath("intllib")) then
  dofile(minetest.get_modpath("intllib").."/intllib.lua")
  S = intllib.Getter(minetest.get_current_modname())
else
  S = function ( s ) return s end
end

minetest.log("action","MOD: dino_irex mod loading ...")
local version = "0.0.1"

local irex_groups = {
						not_in_creative_inventory=1
					}

local selectionbox_irex_adult = {-2.5, -2.54, -1.75, 1.8, 3.7, 1.75}
local selectionbox_juv = {-1.8, -1.54, -0.75, 1.8, 0.7, 0.75}
local selectionbox_hatch = {-0.2, -0.2, -0.2, 0.2, 0.2, 0.2}

local modpath = minetest.get_modpath("dino_irex")

local function irex_drop()

	local result = {}
	if math.random() < 0.05 then
		table.insert(result,"dinodrops:irex_skull")
	else
		table.insert(result,"dinodrops:irex_meat")
        end

	return result
end

local function egg_timeout(entity)

	if math.random() < 0.05 then
		local tospawn = "dino_irex:hatch_f"
		if math.random() > 0.5 then
			tospawn = "dino_irex:hatch_m"
		end

		local eggpos = entity.object:getpos()

		if (pref_mob_around(
						"dino_irex:irexm",
						nil,
						eggpos,
						5,false)) then
			spawning.spawn_and_check(tospawn,eggpos,"spawn_from_chicken_egg")
		end
	end
end

local chicken_prototype = {
		name="irexf",
		modname="dino_irex",

		factions = {
			member = {
				"dinosaurs",
				"cretacous_dinos"
				}
			},

		generic = {
					description= S("Adult Female Indominus"),
					base_health=250,
					kill_result=irex_drop,
					armor_groups= {
						fleshy=90,
					},
					groups = irex_groups,
					envid = "meadow",
					population_density=75,
				},
		movement =  {
					min_accel=0.2,
					max_accel=0.20,
					max_speed=0.2,
					min_speed=0.2,
					pattern="stop_and_go",
					canfly = false,
					},
		catching = {
					tool="ctools:gun",
					consumed=false,
					},
		combat = {
					starts_attack=true,
					sun_sensitive=false,
		                        attack_hostile_mobs=true,
	                        	attack_friendly_mobs=true,
					melee = {
						maxdamage=45,
						range=5,
						speed=0.3,
						},
					distance 		= nil,
					self_destruct 	= nil,
					},
		random_drop = nil,
		sound = {
						},
					random = {
						name= {
							"dino_irex_adult",
							},
						min_delta = 30,
						chance = 0.3,
						gain = 1,
						max_hear_distance = 55,
					},
		animation = {
				walk = {
					start_frame = 30,
					end_frame   = 50,
					},
				stand = {
					start_frame = 1,
					end_frame   = 20,
					},
			},
		attention = {
				hear_distance = 100,
				hear_distance_value = 0.90,
				view_angle = math.pi/2,
				own_view_value = 0.4,
				remote_view = false,
				remote_view_value = 0,
				attention_distance_value = 0.2,
				watch_threshold = 10,
				attack_threshold = 10,
				attention_distance = 20,
				attention_max = 100,
                },
		states = {
				{
				name = "default",
				movgen = "none",
				chance = 0.50,
				animation = "stand",
				graphics_3d = {
					visual = "mesh",
					mesh = "dino_irex.b3d",
					textures = {"female_irex_mesh.png"},
					collisionbox = selectionbox_irex_adult,
					visual_size= {x=2,y=2,z=2},
					},
				graphics = {
					sprite_scale={x=1,y=1},
					sprite_div = {x=6,y=1},
					visible_height = 1,
					visible_width = 1,
					},
				typical_state_time = 30,
				},
				{
				name = "walking",
				movgen = "probab_mov_gen",
				chance = 0.50,
				animation = "walk",
				typical_state_time = 180,
				},
				{
				name = "combat",
				typical_state_time = 9999,
				chance = 0.0,
				animation = "walk",
				movgen = "follow_mov_gen"
				},
			},
		}

local rooster_prototype = {
		name="irexm",
		modname="dino_irex",

		factions = {
			member = {
				"dinosaurs",
				"cretacous_dinos"
				}
			},

		generic = {
					description= S("Adult Male Indominus"),
					base_health=250,
					kill_result=irex_drop,
					armor_groups= {
						fleshy=90,
					},
					groups = irex_groups,
					envid = "meadow",
					population_density=75,
				},
		movement =  {
					min_accel=0.2,
					max_accel=0.2,
					max_speed=0.2,
					min_speed=0.2,
					pattern="stop_and_go",
					canfly = false,
					},
		catching = {
					tool="ctools:gun",
					consumed=false,
					},
		combat = {
					starts_attack=true,
					sun_sensitive=false,
					melee = {
						maxdamage=30,
						range=10,
						speed=0.3,
						},
					distance 		= nil,
					self_destruct 	= nil,
					},
		sound = {
					random = {
						name="dino_irex_adult",
						min_delta = 30,
						chance = 0.5,
						gain = 5,
						max_hear_distance = 50,
					},
			},
		animation = {
				walk = {
					start_frame = 30,
					end_frame   = 50,
					},
				stand = {
					start_frame = 1,
					end_frame   = 20,
					},
			},
		attention = {
				hear_distance = 20,
				hear_distance_value = 30,
				view_angle = math.pi/2,
				own_view_value = 0.4,
				remote_view = false,
				remote_view_value = 0,
				attention_distance_value = 0.2,
				watch_threshold = 10,
				attack_threshold = 10,
				attention_distance = 20,
				attention_max = 25,
                },
		states = {
				{
				name = "default",
				movgen = "none",
				chance = 0.50,
				animation = "stand",
				graphics_3d = {
					visual = "mesh",
					mesh = "dino_irex.b3d",
					textures = {"male_irex_mesh.png"},
					collisionbox = selectionbox_irex_adult,
					visual_size= {x=2,y=2,z=2},
					},
				graphics = {
					sprite_scale={x=1,y=1},
					sprite_div = {x=6,y=1},
					visible_height = 1,
					visible_width = 1,
					},
				typical_state_time = 30,
				},
				{
				name = "walking",
				movgen = "probab_mov_gen",
				chance = 0.50,
				animation = "walk",
				typical_state_time = 180,
				},
				{
				name = "combat",
				typical_state_time = 9999,
				chance = 0.0,
				animation = "walk",
				movgen = "follow_mov_gen"
				},
			},
		}

local juvirex_m_prototype = {
		name="juvirexm",
		modname="dino_irex",

		factions = {
			member = {
				"dinosaurs",
				"cretaceous_dinos"
				}
			},

		generic = {
				description= S("Male Juvenile Indominus"),
				base_health=110,
				kill_result="dinodrops:irex_meat",
				armor_groups= {
					fleshy=90,
				},
				groups = irex_groups,
				envid = "meadow"
				},
		movement =  {
				min_accel=0.2,
				max_accel=0.2,
				max_speed=0.2,
				min_speed=0.2,
				pattern="stop_and_go",
				canfly = false,
				},
		catching = {
				tool="ctools:gun",
				consumed=false,
				},
		auto_transform = {
				result="dino_irex:irexm",
				delay=21900,
				},
		animation = {
				walk = {
					start_frame = 30,
					end_frame   = 50,
					},
				stand = {
					start_frame = 1,
					end_frame   = 20,
					},
			},
		states = {
				{
				name = "default",
				movgen = "none",
				chance = 0,
				animation = "stand",
				graphics_3d = {
					visual = "mesh",
					mesh = "dino_irex.b3d",
					textures = {"male_irex_mesh.png"},
					collisionbox = selectionbox_juv,
					visual_size= {x=1,y=1,z=1},
					},
				graphics = {
					sprite_scale={x=1,y=1},
					sprite_div = {x=6,y=1},
					visible_height = 1,
					visible_width = 1,
					},
				typical_state_time = 30,
				},
				{
				name = "walking",
				movgen = "probab_mov_gen",
				chance = 0.50,
				animation = "walk",
				typical_state_time = 180,
				},
				{
				name = "combat",
				typical_state_time = 9999,
				chance = 0.0,
				animation = "walk",
				movgen = "follow_mov_gen"
				},
			},
		}

local juvirex_f_prototype = {
		name="juvirexf",
		modname="dino_irex",

		factions = {
			member = {
				"dinosaurs",
				"cretaceous_dinos"
				}
			},

		generic = {
				description= S("Female Juvenile Indominus"),
				base_health=110,
				kill_result="dinodrops:irex_meat",
				armor_groups= {
					fleshy=90,
				},
				groups = irex_groups,
				envid = "meadow"
				},
		movement =  {
				min_accel=0.2,
				max_accel=0.2,
				max_speed=0.2,
				min_speed=0.2,
				pattern="stop_and_go",
				canfly = false,
				},
		catching = {
				tool="ctools:gun",
				consumed=false,
				},
		auto_transform = {
				result="dino_irex:irexf",
				delay=21900,
				},
		animation = {
				walk = {
					start_frame = 30,
					end_frame   = 50,
					},
				stand = {
					start_frame = 1,
					end_frame   = 20,
					},
			},
		states = {
				{
				name = "default",
				movgen = "none",
				chance = 0.50,
				animation = "stand",
				graphics_3d = {
					visual = "mesh",
					mesh = "dino_irex.b3d",
					textures = {"female_irex_mesh.png"},
					collisionbox = selectionbox_juv,
					visual_size= {x=1,y=1,z=1},
					},
				graphics = {
					sprite_scale={x=1,y=1},
					sprite_div = {x=6,y=1},
					visible_height = 1,
					visible_width = 1,
					},
				typical_state_time = 30,
				},
				{
				name = "walking",
				movgen = "probab_mov_gen",
				chance = 0.50,
				animation = "walk",
				typical_state_time = 180,
				},
				{
				name = "combat",
				typical_state_time = 9999,
				chance = 0.0,
				animation = "walk",
				movgen = "follow_mov_gen"
				},
			},
		}

local hatch_m_prototype = {
		name="hatch_m",
		modname="dino_irex",

		factions = {
			member = {
				"dinosaurs",
				"cretaceous_dinos"
				}
			},

		generic = {
				description= S("Male Indominus Hatchling"),
				base_health=50,
				kill_result="dinodrops:irex_meat",
				armor_groups= {
					fleshy=90,
				},
				groups = irex_groups,
				envid = "meadow"
				},
		movement =  {
				min_accel=0.2,
				max_accel=0.2,
				max_speed=0.2,
				min_speed=0.2,
				pattern="stop_and_go",
				canfly = false,
				},
		catching = {
				tool="ctools:gun",
				consumed=false,
				},
		auto_transform = {
				result="dino_irex:juvirexm",
				delay=32850,
				},
		animation = {
				walk = {
					start_frame = 30,
					end_frame   = 50,
					},
				stand = {
					start_frame = 1,
					end_frame   = 20,
					},
			},
		states = {
				{
				name = "default",
				movgen = "none",
				chance = 0.50,
				animation = "stand",
				graphics_3d = {
					visual = "mesh",
					mesh = "dino_irex.b3d",
					textures = {"male_irex_hatchling_mesh.png"},
					collisionbox = selectionbox_hatch,
					visual_size= {x=0.1,y=0.1,z=0.1},
					},
				graphics = {
					sprite_scale={x=1,y=1},
					sprite_div = {x=6,y=1},
					visible_height = 1,
					visible_width = 1,
					},
				typical_state_time = 30,
				},
				{
				name = "walking",
				movgen = "probab_mov_gen",
				chance = 0.50,
				animation = "walk",
				typical_state_time = 180,
				},
			},
		}

local hatch_f_prototype = {
		name="hatch_f",
		modname="dino_irex",

		factions = {
			member = {
				"dinosaurs",
				"cretaceous_dinos"
				}
			},

		generic = {
				description= S("Female Indominus Hatchling"),
				base_health=50,
				kill_result="dinodrops:irex_meat",
				armor_groups= {
					fleshy=90,
				},
				groups = irex_groups,
				envid = "meadow"
				},
		movement =  {
				min_accel=0.2,
				max_accel=0.2,
				max_speed=0.2,
				min_speed=0.2,
				pattern="stop_and_go",
				canfly = false,
				},
		catching = {
				tool="ctools:gun",
				consumed=false,
				},
		auto_transform = {
				result="dino_irex:juvirexf",
				delay=32850,
				},
		animation = {
				walk = {
					start_frame = 30,
					end_frame   = 50,
					},
				stand = {
					start_frame = 1,
					end_frame   = 20,
					},
			},
		states = {
				{
				name = "default",
				movgen = "none",
				chance = 0.50,
				animation = "stand",
				graphics_3d = {
					visual = "mesh",
					mesh = "dino_irex.b3d",
					textures = {"female_irex_hatchling_mesh.png"},
					collisionbox = selectionbox_hatch,
					visual_size= {x=0.1,y=0.1,z=0.1},
					},
				graphics = {
					sprite_scale={x=1,y=1},
					sprite_div = {x=6,y=1},
					visible_height = 1,
					visible_width = 1,
					},
				typical_state_time = 30,
				},
				{
				name = "walking",
				movgen = "probab_mov_gen",
				chance = 0.50,
				animation = "walk",
				typical_state_time = 180,
				},
			},
		}

local chicken_name   = chicken_prototype.modname .. ":"  .. chicken_prototype.name
local rooster_name = rooster_prototype.modname .. ":"  .. rooster_prototype.name

local chicken_env = pref_environment_by_name(chicken_prototype.generic.envid)

pref_spawner_register("chicken_spawner_1",chicken_name,
	{
	spawnee = chicken_name,
	spawn_interval = 120,
	spawn_inside = chicken_env.media,
	entities_around =
		{
			{ type="MAX",distance=1,threshold=0 },
			{ type="MAX",entityname=chicken_name,
				distance=chicken_prototype.generic.population_density,threshold=2 },
			{ type="MAX",entityname=rooster_name,
				distance=chicken_prototype.generic.population_density,threshold=2 }
		},

	nodes_around =
		{
			{ type="MIN", name = { "mesozoic:grass", },distance=8,threshold=1}
		},

	absolute_height =
	{
		min = -10,
	},

	mapgen =
	{
		enabled = true,
		retries = 20,
		spawntotal = 3,
	},

	surfaces = chicken_env.surfaces.good,
	collisionbox = selectionbox_irex_adult
	})

pref_spawner_register("rooster_spawner_1",rooster_name,
	{
	spawnee = rooster_name,
	spawn_interval = 120,
	spawn_inside = chicken_env.media,
	entities_around =
		{
			{ type="MAX",distance=1,threshold=0 },
			{ type="MAX",entityname=chicken_name,
				distance=chicken_prototype.generic.population_density,threshold=2 },
			{ type="MAX",entityname=rooster_name,
				distance=chicken_prototype.generic.population_density,threshold=2 }
		},

	nodes_around =
		{
			{ type="MIN", name = { "mesozoic:grass", },distance=8,threshold=1}
		},

	absolute_height =
	{
		min = -10,
	},

	mapgen =
	{
		enabled = true,
		retries = 20,
		spawntotal = 3,
	},

	surfaces = chicken_env.surfaces.good,
	collisionbox = selectionbox_irex_adult
	})

--register with animals mod
minetest.log("action","\tadding animal "..chicken_prototype.name)
pref_add_mob(chicken_prototype)
minetest.log("action","\tadding animal "..hatch_m_prototype.name)
pref_add_mob(hatch_m_prototype)
minetest.log("action","\tadding animal "..hatch_f_prototype.name)
pref_add_mob(hatch_f_prototype)
minetest.log("action","\tadding animal "..rooster_prototype.name)
pref_add_mob(rooster_prototype)
minetest.log("action","\tadding animal "..juvirex_m_prototype.name)
pref_add_mob(juvirex_m_prototype)
minetest.log("action","\tadding animal "..juvirex_f_prototype.name)
pref_add_mob(juvirex_f_prototype)
minetest.log("action","MOD: dino_irex mod         version " .. version .. " loaded")
